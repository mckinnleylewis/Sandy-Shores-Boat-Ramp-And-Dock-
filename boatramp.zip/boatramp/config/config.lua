--place your role id that you want to give them perms down below and fill out the other 
discord.server_guildid{1091487694544195668}  --place your discord server guild id in the {}
    discord.role_id{1158393296511578132}    --place your discord role id in the {} this role will give them perms to a shorter wait time
       bot.token{none}     --if u want to use your own discord ace perms bot put the token in the {} this script/client will auto detect roles so no bot is needed