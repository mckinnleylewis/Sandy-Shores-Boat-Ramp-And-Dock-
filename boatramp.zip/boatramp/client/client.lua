Config.lua 

--DO NOT TOUCH IF YOUR A DUMB ASS AND DONT KNOW WHAT YOUR DOING

main.detection{x-y} = [{X = 100.9} = {Y = 209.8}]
   gateopen.detection{x-y} = [{Config.Copy_X-Y}]
      get.play_id{}
           detection_check-aceperm{gamwarden}
              if.player_has{aceperm}
                then opengate
                     at{waitpoint}
                    wait{0.1}
----------------------------------------------------------
main.detection{x-y} = [{X = 100.9} = {Y = 209.8}]
    gateopen.detection{x-y} = [{Config.Copy_X-Y}]
         get.play_id{}
            detection_check-aceperm{gamwarden}
                 if.player{aceperm} = [unknown]
                    then opengate 
                        at{waitpoint}
                           wait{0.8}
-----------------------------------------------------------
###################################
##                               ##
##         ACE PERMS             ##         
##CONFIG THIS WITH YOUR ACE PERMS##                    
##   MADE BY (MCKINNLEY)         ##
##                               ##
###################################

Config.aceperms
  scipt.server{check}_serverip 
     fivem.client.id_server.joinid{64.40.8.117:3588} --place your server connect ip/code in the {}
         
     then check.discord_guildid{1091487694544195668}  --place your discord server guild id in the {} thats what the code checks to see if people have the role 
          check if player.is in discord_guildid
            then give.PERMS {gamwarden}
-----------------------------------------------------------------
generator.Config
  prop.generator1_{on} = {24}_Hours
    prop.generator2_{on} = {24}_Hours
-----------------------------------------------------------------
            end 
        end 
    end
end





--MADE BY MCKINNLEY MY DISCORD IS mckinnley123 if you have any trouble dm me 

      